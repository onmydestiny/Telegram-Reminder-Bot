import asyncio
import logging
import sqlite3
from datetime import datetime, timedelta
import pytz
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from environs import Env


logging.basicConfig(level=logging.INFO)


env = Env()
env.read_env()
BOT_TOKEN = env.str('BOT_TOKEN')
TIMEZONE = env.str('TIMEZONE', 'Europe/Kiev')


main_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="➕ Создать напоминание")],
        [
            KeyboardButton(text="📝 Все напоминания"),
            KeyboardButton(text="🗑 Удалить напоминание")
        ],
        [KeyboardButton(text="⚙️ Настройки")]
    ],
    resize_keyboard=True
)

repeat_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Без повтора", callback_data="repeat_no"),
            InlineKeyboardButton(text="Ежедневно", callback_data="repeat_daily")
        ],
        [
            InlineKeyboardButton(text="Еженедельно", callback_data="repeat_weekly"),
            InlineKeyboardButton(text="Ежемесячно", callback_data="repeat_monthly")
        ],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
    ]
)

weekdays_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Пн", callback_data="day_1"),
            InlineKeyboardButton(text="Вт", callback_data="day_2"),
            InlineKeyboardButton(text="Ср", callback_data="day_3")
        ],
        [
            InlineKeyboardButton(text="Чт", callback_data="day_4"),
            InlineKeyboardButton(text="Пт", callback_data="day_5"),
            InlineKeyboardButton(text="Сб", callback_data="day_6")
        ],
        [InlineKeyboardButton(text="Вс", callback_data="day_7")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
    ]
)

categories_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Разовые", callback_data="show_no"),
            InlineKeyboardButton(text="Ежедневные", callback_data="show_daily")
        ],
        [
            InlineKeyboardButton(text="Еженедельные", callback_data="show_weekly"),
            InlineKeyboardButton(text="Ежемесячные", callback_data="show_monthly")
        ],
        [InlineKeyboardButton(text="Все", callback_data="show_all")]
    ]
)


class ReminderDB:
    def __init__(self):
        self.conn = sqlite3.connect('reminders.db')
        self._migrate_db()
    
    def _migrate_db(self):
        cursor = self.conn.cursor()
        
        
        cursor.execute("PRAGMA table_info(reminders)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if not columns:
            
            self._create_table()
        elif 'is_completed' not in columns:
            
            cursor.execute('ALTER TABLE reminders ADD COLUMN is_completed INTEGER DEFAULT 0')
            self.conn.commit()
    
    def _create_table(self):
        cursor = self.conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY,
            user_id INTEGER,
            text TEXT,
            time TEXT,
            repeat_type TEXT,
            repeat_day INTEGER DEFAULT 0,
            is_completed INTEGER DEFAULT 0
        )''')
        self.conn.commit()
    
    def add_reminder(self, user_id: int, text: str, time: str, repeat_type: str, repeat_day: int = 0):
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO reminders (user_id, text, time, repeat_type, repeat_day) VALUES (?, ?, ?, ?, ?)',
            (user_id, text, time, repeat_type, repeat_day)
        )
        self.conn.commit()
    
    def get_active_reminders(self, current_time: str):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM reminders 
            WHERE time = ? 
            AND (is_completed IS NULL OR is_completed = 0)
        ''', (current_time,))
        return cursor.fetchall()
    
    def get_user_reminders(self, user_id: int):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM reminders WHERE user_id = ?', (user_id,))
        return cursor.fetchall()
    
    def delete_reminder(self, reminder_id: int, user_id: int):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM reminders WHERE id = ? AND user_id = ?', (reminder_id, user_id))
        self.conn.commit()
        return cursor.rowcount > 0
    
    def get_reminders_by_type(self, user_id: int, repeat_type: str):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM reminders WHERE user_id = ? AND repeat_type = ?', (user_id, repeat_type))
        return cursor.fetchall()
    
    def mark_completed(self, reminder_id: int):
        cursor = self.conn.cursor()
        cursor.execute('''
            UPDATE reminders 
            SET is_completed = 1 
            WHERE id = ? AND repeat_type = 'no'
        ''', (reminder_id,))
        self.conn.commit()


class ReminderStates(StatesGroup):
    waiting_for_text = State()
    waiting_for_time = State()
    waiting_for_repeat = State()
    waiting_for_timezone = State()


bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
db = ReminderDB()
tz = pytz.timezone(TIMEZONE)


@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    await message.answer(
        "Привет! Я бот для напоминаний. Используйте кнопки ниже для управления:",
        reply_markup=main_kb
    )

@dp.message(F.text == "➕ Создать напоминание")
async def create_reminder(message: types.Message, state: FSMContext):
    await state.set_state(ReminderStates.waiting_for_text)
    await message.answer("Введите текст напоминания:")

@dp.message(ReminderStates.waiting_for_text)
async def process_reminder_text(message: types.Message, state: FSMContext):
    await state.update_data(reminder_text=message.text)
    await state.set_state(ReminderStates.waiting_for_time)
    await message.answer("Введите время для напоминания в формате ЧЧ:ММ\nНапример: 14:30")

@dp.message(ReminderStates.waiting_for_time)
async def process_reminder_time(message: types.Message, state: FSMContext):
    try:
        time = datetime.strptime(message.text, "%H:%M")
        await state.update_data(reminder_time=message.text)
        await state.set_state(ReminderStates.waiting_for_repeat)
        await message.answer("Выберите периодичность напоминания:", reply_markup=repeat_kb)
    except ValueError:
        await message.answer("Неверный формат времени. Пожалуйста, используйте формат ЧЧ:ММ")

@dp.callback_query(lambda c: c.data.startswith("repeat_"))
async def process_repeat_type(callback: types.CallbackQuery, state: FSMContext):
    repeat_type = callback.data.split("_")[1]
    data = await state.get_data()
    
    if repeat_type == "weekly":
        await callback.message.edit_text("Выберите день недели:", reply_markup=weekdays_kb)
        return
    
    db.add_reminder(
        callback.from_user.id,
        data['reminder_text'],
        data['reminder_time'],
        repeat_type
    )
    
    await state.clear()
    await callback.message.answer("Напоминание создано!", reply_markup=main_kb)

@dp.callback_query(lambda c: c.data.startswith("day_"))
async def process_weekday(callback: types.CallbackQuery, state: FSMContext):
    day = int(callback.data.split("_")[1])
    data = await state.get_data()
    
    db.add_reminder(
        callback.from_user.id,
        data['reminder_text'],
        data['reminder_time'],
        'weekly',
        day
    )
    
    await state.clear()
    await callback.message.answer("Напоминание создано!", reply_markup=main_kb)

@dp.message(F.text == "📝 Все напоминания")
async def show_categories(message: types.Message):
    await message.answer("Выберите категорию напоминаний:", reply_markup=categories_kb)

@dp.callback_query(lambda c: c.data.startswith("show_"))
async def show_category_reminders(callback: types.CallbackQuery):
    category = callback.data.split("_")[1]
    if (category == "all"):
        reminders = db.get_user_reminders(callback.from_user.id)
    else:
        reminders = db.get_reminders_by_type(callback.from_user.id, category)
    
    if not reminders:
        await callback.message.edit_text("В этой категории нет напоминаний")
        return
    
    text = "Напоминания в категории:\n\n"
    weekdays = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"]
    for r in reminders:
        repeat_info = {
            'no': 'без повтора',
            'daily': 'ежедневно',
            'weekly': f'еженедельно ({weekdays[r[5]-1] if r[5] else "?"})',
            'monthly': 'ежемесячно'
        }
        text += f"🔔 {r[2]} - {r[3]} ({repeat_info[r[4]]})\n"
    
    await callback.message.edit_text(text)

@dp.message(F.text == "🗑 Удалить напоминание")
async def delete_reminder_menu(message: types.Message):
    reminders = db.get_user_reminders(message.from_user.id)
    if not reminders:
        await message.answer("У вас нет активных напоминаний")
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"{r[2]} - {r[3]}", 
            callback_data=f"delete_{r[0]}"
        )] for r in reminders
    ] + [[InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]])
    
    await message.answer("Выберите напоминание для удаления:", reply_markup=kb)

@dp.callback_query(lambda c: c.data.startswith("delete_"))
async def delete_reminder_callback(callback: types.CallbackQuery):
    reminder_id = int(callback.data.split("_")[1])
    if db.delete_reminder(reminder_id, callback.from_user.id):
        await callback.message.edit_text("✅ Напоминание удалено!")
    else:
        await callback.message.edit_text("❌ Ошибка при удалении напоминания")

@dp.message(F.text == "⚙️ Настройки")
async def settings(message: types.Message, state: FSMContext):  
    await message.answer(
        f"Текущий часовой пояс: {TIMEZONE}\n"
        "Отправьте название часового пояса для изменения\n"
        "Например: Europe/Moscow, Asia/Tokyo, Europe/Kiev",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")
        ]])
    )
    await state.set_state(ReminderStates.waiting_for_timezone)

@dp.message(ReminderStates.waiting_for_timezone)
async def change_timezone(message: types.Message, state: FSMContext):
    try:
        new_tz = pytz.timezone(message.text)
        
        global tz
        tz = new_tz
        await message.answer("✅ Часовой пояс успешно изменен!", reply_markup=main_kb)
        await state.clear()
    except pytz.exceptions.UnknownTimeZoneError:
        await message.answer("❌ Неверный часовой пояс. Попробуйте еще раз или нажмите отмену.")

@dp.callback_query(lambda c: c.data == "cancel")
async def cancel_operation(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Операция отменена")
    await callback.message.answer("Выберите действие:", reply_markup=main_kb)

@dp.message(F.text == "📝 Мои напоминания")
async def list_reminders(message: types.Message):
    reminders = db.get_user_reminders(message.from_user.id)
    if not reminders:
        await message.answer("У вас нет активных напоминаний")
        return
    
    text = "Ваши напоминания:\n\n"
    weekdays = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"]
    for r in reminders:
        repeat_info = {
            'no': 'без повтора',
            'daily': 'ежедневно',
            'weekly': f'еженедельно ({weekdays[r[5]-1] if r[5] else "?"})',
            'monthly': 'ежемесячно'
        }
        text += f"🔔 {r[2]} - {r[3]} ({repeat_info[r[4]]})\n"
    
    await message.answer(text)

def get_remind_again_kb(reminder_id: int):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🕒 Через 10 минут", callback_data=f"remind_10_{reminder_id}"),
                InlineKeyboardButton(text="🕒 Через 30 минут", callback_data=f"remind_30_{reminder_id}")
            ],
            [
                InlineKeyboardButton(text="🕒 Через 1 час", callback_data=f"remind_60_{reminder_id}"),
                InlineKeyboardButton(text="🕒 Завтра", callback_data=f"remind_tomorrow_{reminder_id}")
            ]
        ]
    )

@dp.callback_query(lambda c: c.data.startswith("remind_"))
async def remind_again(callback: types.CallbackQuery):
    _, minutes, reminder_id = callback.data.split("_")
    reminder_id = int(reminder_id)
    
    cursor = db.conn.cursor()
    cursor.execute('SELECT text FROM reminders WHERE id = ?', (reminder_id,))
    reminder = cursor.fetchone()
    
    if not reminder:
        await callback.answer("Напоминание не найдено!")
        return
    
    now = datetime.now(tz)
    if minutes == "tomorrow":
        new_time = (now + timedelta(days=1)).replace(hour=9, minute=0)
    else:
        new_time = now + timedelta(minutes=int(minutes))
    
    db.add_reminder(
        callback.from_user.id,
        reminder[0],
        new_time.strftime("%H:%M"),
        "no"
    )
    
    db.mark_completed(reminder_id)
    
    await callback.message.edit_text(
        f"{callback.message.text}\n\n✅ Отложено на {new_time.strftime('%H:%M')}"
    )

async def check_reminders():
    while True:
        current_time = datetime.now(tz).strftime("%H:%M")
        reminders = db.get_active_reminders(current_time)
        
        for reminder in reminders:
            await bot.send_message(
                reminder[1],
                f"🔔 Напоминание:\n{reminder[2]}",
                reply_markup=get_remind_again_kb(reminder[0])
            )
            if reminder[4] == 'no':
                db.mark_completed(reminder[0])
        
        await asyncio.sleep(60)

async def main():
    asyncio.create_task(check_reminders())
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())
